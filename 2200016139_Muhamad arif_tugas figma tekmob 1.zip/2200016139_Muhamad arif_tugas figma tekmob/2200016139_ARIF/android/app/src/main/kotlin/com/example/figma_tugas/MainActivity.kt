package com.example.figma_tugas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
